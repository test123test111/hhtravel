﻿// 弹出新窗口
function openwin(pageName) {
    var win = window.open(pageName,
                'newwindow',
                'height=600, width=740, top=0, left=0, toolbar=no, menubar=no, scrollbars=yes, resizable=no,location=no, status=no');
    return win;
}

$(function () {
    //    http: //www.thefutureoftheweb.com/blog/target-blank-xhtml11
    $('a.new-blank').click(function () {
        window.open(this.href);
        return false;
    });

    $('a.new-window').click(function () {
        openwin(this.href);
        return false;
    });

    $('input.date').attr('autocomplete', 'off').attr('maxlength', 10);
});