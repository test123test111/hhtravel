﻿静态资源路径的查找/替换的正则表达式
\.\.{.*}{jpg|htc|gif}
@Url.Content("~\1\2")